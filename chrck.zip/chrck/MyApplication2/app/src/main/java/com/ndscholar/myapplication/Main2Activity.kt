package com.ndscholar.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ndscholar.myapplication.Adaptor.Coustomadapter
import com.ndscholar.myapplication.Adaptor.customadapter
import com.ndscholar.myapplication.Model.User
import java.util.*

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val recyclerView=findViewById<RecyclerView>(R.id.ru)

        recyclerView.layoutManager= LinearLayoutManager(this, RecyclerView.VERTICAL,false)
        val adapter= customadapter(prepareUser())
        recyclerView.adapter=adapter
    }

    fun prepareUser(): List<User> {
        val names = Arrays.asList(*resources.getStringArray(R.array.names))
        val imageid = intArrayOf(R.drawable.ic_home, R.drawable.ic_launcher_background, R.drawable.ic_calendar_day,
                R.drawable.ic_launcher_background, R.drawable.ic_launcher_background, R.drawable.ic_responsive)
        val Names = java.util.ArrayList<User>()
        var count = 0
        for (name in names) {
            Names.add(User(name, imageid[count]))
            count++
        }
        return Names
    }
}

